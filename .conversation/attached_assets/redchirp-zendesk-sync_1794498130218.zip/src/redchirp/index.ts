import { config } from '../config.js';
import { HttpRedChirpClient } from './http.js';
import { MockRedChirpClient } from './mock.js';
import type { RedChirpClient } from './types.js';

export const usingMock = !config.redchirp.apiKey;
export const mockRedChirp = new MockRedChirpClient();
export const redchirp: RedChirpClient = usingMock ? mockRedChirp : new HttpRedChirpClient();
