import { config } from '../config.js';
import type { RedChirpChange, RedChirpClient } from './types.js';

// Real RedChirp client. Each method is wired to an endpoint once the OpenAPI spec is reviewed.
// Until then every call throws, so nothing reaches RedChirp by accident.
const TODO = (what: string) => {
  throw new Error(`RedChirp ${what} is not wired yet. Add the endpoint from the RedChirp OpenAPI spec.`);
};

export class HttpRedChirpClient implements RedChirpClient {
  constructor(private baseUrl = config.redchirp.baseUrl, private apiKey = config.redchirp.apiKey) {}

  async listChangesSince(_cursor: string | null): Promise<{ changes: RedChirpChange[]; nextCursor: string }> {
    return TODO('listChangesSince');
  }
  async sendMessage(_args: { conversationId: string; onBehalfOfUserId: string; text: string }): Promise<{ messageId: string }> {
    return TODO('sendMessage (on behalf of a user)');
  }
  async assign(_args: { conversationId: string; userId: string | null; byUserId?: string }): Promise<void> {
    return TODO('assign');
  }
  async archive(_args: { conversationId: string; byUserId?: string }): Promise<void> {
    return TODO('archive');
  }
  async unarchive(_args: { conversationId: string; byUserId?: string }): Promise<void> {
    return TODO('unarchive');
  }
}
